#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
//global variables
#define CORE 4
#define SIZE 4

int arr_Two_Dim[SIZE][SIZE]; // Matrix
int new_arr[SIZE * SIZE]; // The numbers array
int index_even = 0; // The running index for even numbers
int index_noneven = 1; // The running index for uneven numbers
int arr_Num_Threads[SIZE * SIZE]; // Array to keep for each number which thread found him
int thread_counter = 0; // Threads counter
pthread_t th[CORE]; // Threads array
int count = 0; // Counter
int s = (SIZE * SIZE) / CORE; // Keep the amount of numbers each thread has to discover
int reminder = (SIZE * SIZE) % CORE; // In case we do have a reminder in this division keep it

//the function of the threads
void* Modify(void* arg) 
{
	int temp = (int)arg; // Convert the arg to int
	int start = temp * s; // Current thread starting position
	int end = (temp + 1) * (s)-1; // Current thread ending position
	if ((SIZE * SIZE) % CORE != 0 && temp == CORE -1) // Check if our threads number dosen't divied equally in N*N
	{
		end += (SIZE * SIZE) % CORE; // If so give the last thread a new ending position
	}
	for (int j = start; j <= end; j++)  // Iteratre through the Matrix
	{
		if (arr_Two_Dim[j / SIZE][(j % SIZE)] % 2 == 0) // Check if even
		{
			new_arr[index_even] = arr_Two_Dim[j / SIZE][(j % SIZE)]; // If so put in an even index
			arr_Num_Threads[index_even] = count; // For each group of numbers keep the thread number of the thread that found them.
			index_even += 2;
		}
		else  // If not put in an uneven index
		{ 
			new_arr[index_noneven] = arr_Two_Dim[j / SIZE][(j % SIZE)];
			arr_Num_Threads[index_noneven] = count; // For each group of numbers keep the thread number of the thread that found them.
			index_noneven += 2;
		}
	}
	count++;
	return ((void*)0);
}

int main() {
	//print the matrix
	int i, retcode;
	for (int i = 0; i < SIZE; i++)
	{
		for (int j = 0; j < SIZE; j++)
		{
			arr_Two_Dim[i][j] = j + 1 + (SIZE * i); // Fill the matrix
		}
	}

	printf("Matrix:\n");
	for (int i = 0; i < SIZE; i++) {
		for (int j = 0; j < SIZE; j++) {
			printf(" %d ", arr_Two_Dim[i][j]); // Print the matrix
			
		}
		printf("\n");
	}
	printf("\n");
	//create the threads
	for (i = 0; i < CORE; i++) 
	{
		retcode = pthread_create(&th[i], NULL, Modify, (void*)(i));
		if (retcode != 0)
			printf("Create thread failed with error %d\n", retcode);
	}

	//wait for the threads
	for (i = 0; i < CORE; i++) 
	{
		pthread_join(th[i], NULL);
	}

	//print the new array
	printf("\nThe arranged array: \n");
	for (i = 0; i < SIZE * SIZE; i++) {
		printf("%d ", new_arr[i]);
	}

	printf("\n\n");
	 
	//print the numbers in the array and whice thread insert them
	for (i = 0; i < SIZE * SIZE; i++) {
		printf("Num %d was found by thread %d\n", new_arr[i], arr_Num_Threads[i]);
	}

	exit(0);

}